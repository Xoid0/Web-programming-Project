function handleLogin(event) {
    event.preventDefault();  

    
    const role = document.getElementById('role').value;

    
    if (role === 'designer') {
        window.location.href = 'designer.html';  
    } else if (role === 'player') {
        window.location.href = 'player.html'; 
    }
}
